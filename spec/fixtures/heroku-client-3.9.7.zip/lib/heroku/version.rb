module Heroku
  VERSION = "3.9.7"
end
